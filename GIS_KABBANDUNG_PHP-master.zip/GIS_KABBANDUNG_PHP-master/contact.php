  <?php include("template/header.php");?>

  <body>
  
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <?php include("template/menu.php");?>
    </div>

    <div class="container">
      <h2>Contact</h2>
    </div>  
   
    
  </body>
</html>
