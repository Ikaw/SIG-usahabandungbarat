  <?php include("template/header.php");?>
  <body>
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <?php include("template/menu.php");?>
    </div>

    <div class="container">
       <h2 align="center">GAGAL LOGIN SILAHKAN COBA KEMBALI</h2>
    </div>  
       <script>
    $("#formLogin").validator();
   </script>
  </body>
</html>
