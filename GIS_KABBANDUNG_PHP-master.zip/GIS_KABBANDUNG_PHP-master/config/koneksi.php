<?php

mysql_connect("localhost","root","odong");
 $connect=mysql_select_db("gis") or die(mysql_eror());		
	
?>