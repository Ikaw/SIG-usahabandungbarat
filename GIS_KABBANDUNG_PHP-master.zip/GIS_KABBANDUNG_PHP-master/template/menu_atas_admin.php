 <div class="container-fluid">
	<div class="navbar-header">
	  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
	    <span class="sr-only">Toggle navigation</span>
	    <span class="icon-bar"></span>
	    <span class="icon-bar"></span>
	    <span class="icon-bar"></span>
	  </button>
	  <a class="navbar-brand" href="#"><img src="../images/logo.png" style="vertical-align:top; margin-top:-12px;">Sistem Informasi Geografis Usaha Kab. Bandung Barat</a>
	</div>
	<div class="navbar-collapse collapse">
	  <ul class="nav navbar-nav navbar-right">
	    <li><a href="#">Hi,<?php echo $_SESSION['nama'];?></a></li>
	    <li><a href="profile.php">Profile</a></li>
	    <li><a href="../logout.php">Logout</a></li>
	  </ul>
	  <form class="navbar-form navbar-right">
	   
	  </form>
	</div>
</div>